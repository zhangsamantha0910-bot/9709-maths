window.addEventListener('message', async event=>{
  const data=event.data;
  if(event.source!==window || event.origin!==location.origin || data?.channel!=='9709-request')return;
  let result;
  try {result=await chrome.runtime.sendMessage({file:data.file});} catch {result={error:'Extension unavailable'};}
  window.postMessage({channel:'9709-result',id:data.id,...result},location.origin);
});
document.documentElement.dataset.paperReader='1';
