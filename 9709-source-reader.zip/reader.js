const sources=['https://pastpapers.papacambridge.com/directories/CAIE/CAIE-pastpapers/upload/','https://papers.xtremepape.rs/CAIE/AS%20and%20A%20Level/Mathematics%20%289709%29/'];
async function downloadPaper(file){
  for(const base of sources){
    try{
      const r=await fetch(base+file,{credentials:'omit',redirect:'error',signal:AbortSignal.timeout(20000)});
      if(!r.ok)continue;
      const bytes=new Uint8Array(await r.arrayBuffer());
      if(bytes.length>20*1024*1024 || new TextDecoder().decode(bytes.slice(0,5))!=='%PDF-')continue;
      let binary='';
      for(let i=0;i<bytes.length;i+=16384)binary+=String.fromCharCode(...bytes.subarray(i,i+16384));
      return {pdf:btoa(binary)};
    }catch{ /* Try the second archive. */ }
  }
  return {error:'Source unavailable'};
}
chrome.runtime.onMessage.addListener((m,sender,respond)=>{
  if(!sender.url?.startsWith('https://zhangsamantha0910-bot.github.io/9709-maths/') || typeof m.file!=='string' || !/^9709_[msw]\d{2}_(qp|ms)_[156][1235]\.pdf$/.test(m.file))return false;
  downloadPaper(m.file).then(respond,()=>respond({error:'Download failed'}));
  return true;
});
